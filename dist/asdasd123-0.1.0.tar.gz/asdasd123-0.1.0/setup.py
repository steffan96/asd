# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['asdasd123']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'asdasd123',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'steffan96',
    'author_email': 'stefanmilicic@yahoo.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/steffan96/asd',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
